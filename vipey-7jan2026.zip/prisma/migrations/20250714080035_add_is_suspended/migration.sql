-- AlterTable
ALTER TABLE `User` ADD COLUMN `isSuspended` BOOLEAN NOT NULL DEFAULT false;
